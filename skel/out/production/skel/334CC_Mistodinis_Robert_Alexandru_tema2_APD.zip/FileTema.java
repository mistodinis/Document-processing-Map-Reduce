import java.util.Comparator;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class FileTema  {

    private String fileName;
    private ConcurrentHashMap<Integer,Integer> hashMap;
    private AtomicInteger maxLength ;
    private double rank;

    public FileTema(String fileName, ConcurrentHashMap<Integer, Integer> hashMap, AtomicInteger maxLength) {
        this.fileName = fileName;
        this.hashMap = hashMap;
        this.maxLength = maxLength;
    }

    public FileTema(FileTema fileTema){
        this.fileName = fileTema.getFileName();
        this.hashMap = fileTema.getHashMap();
        this.maxLength = fileTema.getMaxLength();
        this.rank = fileTema.rank;
    }

    public double getRank() {
        return rank;
    }

    public void setRank(double rank) {
        this.rank = rank;
    }

    public AtomicInteger getMaxLength() {
        return maxLength;
    }

    public void setMaxLength(AtomicInteger maxLength) {
        this.maxLength = maxLength;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public ConcurrentHashMap<Integer, Integer> getHashMap() {
        return hashMap;
    }

    public void setHashMap(ConcurrentHashMap<Integer, Integer> hashMap) {
        this.hashMap = hashMap;
    }

}
