import java.io.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.atomic.AtomicInteger;

public class Tema2 {

    public static CyclicBarrier barrier;


    public static void main(String[] args) {
        if (args.length < 3) {
            System.err.println("Usage: Tema2 <workers> <in_file> <out_file>");
            return;
        }
        int numberOfWorkers = Integer.parseInt(args[0]);
        Tema2.barrier = new CyclicBarrier(numberOfWorkers);
        Thread[] threads = new Thread[numberOfWorkers];

        File rootFile = new File(args[1]);

        try {
            Scanner scanner = new Scanner(rootFile);
            int segmentSize = Integer.parseInt(scanner.nextLine());
            int numberOfFiles = Integer.parseInt(scanner.nextLine());
            List<String> files = new ArrayList<>();
            List<String> workers = new ArrayList<>();
            List<Worker> workerList = new ArrayList<>();
            List<FileTema> fileTemaList = Collections.synchronizedList(new ArrayList<>());
            AtomicInteger atomicInteger = new AtomicInteger(1);
            FileWriter myWriter = new FileWriter(args[2]);

            while (scanner.hasNextLine()) {
                files.add(scanner.nextLine());
            }

            for (String file : files) {

                byte[] buffer = new byte[10];
                byte[] secondBuffer = new byte[10];
                List<Byte> parseBuffer = new LinkedList<>();
                FileInputStream in = new FileInputStream(file);
                int rc = in.read(buffer);
                String firstString, secondString;
                fileTemaList.add(new FileTema(file, new ConcurrentHashMap<>(), atomicInteger));

                if (rc != -1) {
                    firstString = new String(buffer);
                    rc = in.read(secondBuffer);
                }

                while (rc != -1) {

                    if (rc < 10) {
                        for (int i = rc; i < secondBuffer.length; i++) {
                            secondBuffer[i] = 0;
                        }
                    }

                    firstString = new String(buffer);
                    secondString = new String(secondBuffer);

                    parseBuffer = new LinkedList<>();

                    if (!checkIfSplitter(buffer[9])) {

                        for (byte bytex : buffer) {
                            if (bytex == 0)
                                continue;
                            parseBuffer.add(bytex);
                        }

                        for (int i = 0; i < secondBuffer.length; i++) {
                            if (checkIfSplitter(secondBuffer[i])) {
                                break;
                            }
                            parseBuffer.add(secondBuffer[i]);

                            secondBuffer[i] = 0;
                        }
                    } else {

                        for (byte bytex : buffer) {
                            if (bytex == 0)
                                continue;
                            parseBuffer.add(bytex);
                        }
                    }

                    Byte[] parseBufferArray = parseBuffer.toArray(new Byte[0]);
                    byte[] arr = new byte[parseBufferArray.length];
                    int i = 0;

                    for (Byte bytex : parseBufferArray) {
                        arr[i++] = bytex;
                    }

                    String testString = new String(arr);

                    workers.add(testString);
                    workerList.add(new Worker(file, testString));
                    buffer = secondBuffer.clone();

                    rc = in.read(secondBuffer);
                }

                parseBuffer = new ArrayList<>();
                for (byte bytex : buffer) {
                    if (bytex == 0)
                        continue;
                    parseBuffer.add(bytex);
                }

                Byte[] parseBufferArray = parseBuffer.toArray(new Byte[0]);
                byte[] arr = new byte[parseBufferArray.length];
                int i = 0;

                for (Byte bytex : parseBufferArray) {
                    arr[i++] = bytex;
                }

                String testString = new String(arr);


                workers.add(testString);
                workerList.add(new Worker(file, testString));

            }

            scanner.close();
            MapTema.value = new AtomicInteger(0);
            for (int i = 0; i < numberOfWorkers; i++) {
                threads[i] = new Thread(new MapTema(i, numberOfWorkers, workers, workerList, fileTemaList));
            }

            for (int i = 0; i < numberOfWorkers; i++) {
                threads[i].start();
            }

            for (int i = 0; i < numberOfWorkers; i++) {
                try {
                    threads[i].join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            List<Integer> fibonacciList = fibonacci(MapTema.value.get());
            double[] rang = new double[fileTemaList.size()];
            int i = 0;


            for (FileTema fileTema : fileTemaList) {

                for (Map.Entry<Integer, Integer> mapEntry : fileTema.getHashMap().entrySet()) {
                    System.out.println("file :" + fileTema.getFileName() + "-> " + mapEntry.getKey() + ":" + mapEntry.getValue());

                }
            }

            for (int j = 0; j < numberOfWorkers; j++) {
                threads[j] = new Thread(new ReduceTema(j, numberOfWorkers, fibonacciList, rang, fileTemaList));
            }

            for (int j = 0; j < numberOfWorkers; j++) {
                threads[j].start();
            }

            for (int j = 0; j < numberOfWorkers; j++) {
                try {
                    threads[j].join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            int k = 0;

            fileTemaList.sort(new FileComparator());

            for (FileTema fileTema : fileTemaList) {


                System.out.println(fileTema.getFileName() + " ->" + String.format("%.2f", fileTema.getRank()) + " , " + fileTema.getMaxLength() + " , " + fileTema.getHashMap().get(fileTema.getMaxLength().get()));
                myWriter.write(fileTema.getFileName() + ".txt," + String.format("%.2f", fileTema.getRank()) + ',' + fileTema.getMaxLength() + ',' + fileTema.getHashMap().get(fileTema.getMaxLength().get()));
            }


        } catch (FileNotFoundException e) {
            System.out.println("Scanner initiation failed!");
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static List<Integer> fibonacci(int rank) {

        int[] result = new int[rank + 2];
        List<Integer> resultList = Collections.synchronizedList(new ArrayList<>());

        if (rank < 0 || rank == 0) {
            System.out.println("Rank invalid! ");
            return null;
        }
        result[0] = 0;
        result[1] = 1;
        resultList.add(0);
        resultList.add(1);

        if (rank == 1) {
            return resultList;
        }

        for (int i = 2; i <= rank + 1; i++) {
            result[i] = result[i - 1] + result[i - 2];
            resultList.add(result[i]);
        }
        return resultList;
    }

    private static boolean checkIfSplitter(byte bytex) {

        return bytex == 10 || bytex == 9 || bytex == 32 || bytex == 33 ||
                bytex == 34 || bytex == 35 || bytex == 36 || bytex == 37 || bytex == 38 || bytex == 39
                || bytex == 40 || bytex == 41 || bytex == 42 || bytex == 43 || bytex == 44 || bytex == 45
                || bytex == 46 || bytex == 47 || bytex == 58 || bytex == 59 || bytex == 60 || bytex == 61
                || bytex == 62 || bytex == 63 || bytex == 64 || bytex == 91 || bytex == 92 || bytex == 93
                || bytex == 94 || bytex == 95 || bytex == 96 || bytex == 123 || bytex == 124 || bytex == 125
                || bytex == 126 || bytex == 0;
    }
}
