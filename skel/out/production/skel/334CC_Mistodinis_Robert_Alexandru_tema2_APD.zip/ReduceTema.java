import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

public class ReduceTema implements Runnable {

    private final int id;
    private final int numberOfThreads;
    private final List<Integer> fibonacci;
    private double[] rang;
    private List<FileTema> fileTemaList;

    public ReduceTema(int id, int numberOfThreads, List<Integer> fibonacci, double[] rang, List<FileTema> fileTemaList) {
        this.id = id;
        this.numberOfThreads = numberOfThreads;
        this.fibonacci = fibonacci;
        this.rang = rang;
        this.fileTemaList = fileTemaList;
    }

    public ReduceTema() {
        this.id = 0;
        this.numberOfThreads = 1;
        this.fibonacci = Collections.synchronizedList(new ArrayList<>());
    }

    private static int[] fibonacci(int rank) {

        int[] result = new int[rank + 2];


        if (rank < 0 || rank == 0) {
            System.out.println("Rank invalid! ");
            return null;
        }
        result[0] = 0;
        result[1] = 1;

        if (rank == 1) {
            return result;
        }

        for (int i = 2; i <= rank + 1; i++) {
            result[i] = result[i - 1] + result[i - 2];

        }

        return result;
    }

    @Override
    public void run() {

        int start = (int) (id * (double) fileTemaList.size() / numberOfThreads);
        int end = Math.min((int) ((id + 1) * (double) fileTemaList.size() / numberOfThreads), fileTemaList.size());
        int[] fibonacciArray = fibonacci(MapTema.value.get());


        for (int i = start; i < end; i++) {
            FileTema fileTema = fileTemaList.get(i);
            int maxLenghtWordPerFile = 0, totalWords = 0;
            AtomicInteger atomicInteger = new AtomicInteger();

            for (Map.Entry<Integer, Integer> mapEntry : fileTema.getHashMap().entrySet()) {
                int numberOfAppearence = mapEntry.getValue();
                int length = mapEntry.getKey();
                if (length > maxLenghtWordPerFile) {
                    maxLenghtWordPerFile = length;

                }
                totalWords += numberOfAppearence;
                rang[i] += fibonacciArray[mapEntry.getKey() + 1] * numberOfAppearence;
            }

            rang[i] /= totalWords;
            fileTemaList.get(i).setRank(rang[i]);
            atomicInteger.set(maxLenghtWordPerFile);
            fileTemaList.get(i).setMaxLength(atomicInteger);
        }
    }
}
