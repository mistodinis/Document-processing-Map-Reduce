import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class MapTema implements Runnable  {


    private final int id;
    private final int numberOfThreads;
//    private final String documentName;
    private final List<String> workers;
    private final List<Worker> workerList;
    private  List<FileTema> fileTemaList;

    public static AtomicInteger value;

    public MapTema(int id, int numberOfThreads, List<String> workers, List<Worker> workerList, List<FileTema> fileTemaList) {
        this.id = id;
        this.numberOfThreads = numberOfThreads;
        this.workers = workers;
        this.workerList = workerList;
        this.fileTemaList = fileTemaList;
    }

    @Override
    public void run() {

        int start = (int)(id * (double) workers.size() / numberOfThreads);
        int end = Math.min((int)((id + 1) * (double) workers.size() / numberOfThreads), workers.size());
        String []words , stringForWords;
        Words words1 = new Words();
        HashMap<Integer,Integer> hashMap = new HashMap<>();
        ConcurrentHashMap<Integer, Integer> auxHashMap;

        for(int i = start;i < end;i++){
            String worker = workers.get(i);
            Worker worker1 = workerList.get(i);
            words1.setFileName(worker1.getFileName());

//            words = worker.split("[;:/?.,><‘\\[\\]{}()!@#$%ˆ&\\-_+’=*”| \t\n\r]");
            words1.setWords(worker.split("[;:/?,.><‘\\[\\]{}()!@#$%ˆ&\\-_+’=*”| \t\n\r]"));

            FileTema fileTema = null;

            for(FileTema fileTema1 : fileTemaList){
                if(fileTema1.getFileName().equals(worker1.getFileName())){
                    fileTema = new FileTema(fileTema1);
                }
            }

            for(String word : words1.getWords()){

                     auxHashMap = fileTema.getHashMap();

                if(word.length() == 0)
                    continue;
                if(auxHashMap.containsKey(word.length())){
                    auxHashMap.put(word.length() , auxHashMap.get(word.length()) + 1);
                }else {
                    int currentHighestLenght = MapTema.value.get();
                    if(currentHighestLenght < word.length()){
                        MapTema.value.set(word.length());
                    }
                    auxHashMap.put(word.length() , 1);
                }
                fileTema.setHashMap(auxHashMap);

            }
        }
    }
}
