public class Worker {

    private String fileName;
    private String worker;

    public Worker(String nameOfFile, String worker) {
        this.fileName = nameOfFile;
        this.worker = worker;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getWorker() {
        return worker;
    }

    public void setWorker(String worker) {
        this.worker = worker;
    }
}
