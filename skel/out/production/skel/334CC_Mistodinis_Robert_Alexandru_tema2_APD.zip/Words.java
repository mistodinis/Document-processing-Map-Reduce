public class Words {

    private String[] words;
    private String fileName;

    public Words() {  }

    public Words(String[] words, String fileName) {
        this.words = words;
        this.fileName = fileName;
    }

    public String[] getWords() {
        return words;
    }

    public void setWords(String[] words) {
        this.words = words;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
}
